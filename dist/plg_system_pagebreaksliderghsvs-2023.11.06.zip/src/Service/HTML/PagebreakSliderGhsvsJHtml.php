<?php
/*
Aufruf via:
HTMLHelper::_('pagebreaksliderghsvs.xyz' ... );
*/

namespace GHSVS\Plugin\System\PagebreakSliderGhsvs\Service\HTML;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Utilities\ArrayHelper;
use GHSVS\Plugin\System\PagebreakSliderGhsvs\Helper\PagebreakSliderGhsvsHelper;

class PagebreakSliderGhsvsJHtml
{
	private $wa;
	protected static $loaded = [];

	public function venobox($selector = null, $options = [])
	{
		$helper = new PagebreakSliderGhsvsHelper();
		$helper->venobox($selector, $options);
	}

	/**
	 * Now Collapse
	*/
	public static function startAccordion($selector = 'myAccordian', $params = [])
	{
		if (!isset(static::$loaded[__METHOD__][$selector]))
		{
			HTMLHelper::_('bootstrap.collapse');
			$this->getWa();
			$divAttributes = [];
			$opt = [];

			// OHNE parent KANNST DU MEHRERE GLEICHZEITIG ÖFFNEN.

			/* Kein Typecast-Vergleich, weil ich noch nicht alle aufrufenden
			Codestellen geprüft habe. */
			if (isset($params['parent']) && $params['parent'])
			{
				$opt['parent'] = '#' . $selector;
			}

			if (isset($opt['parent']))
			{
				$divAttributes['aria-multiselectable'] = 'false';
			}
			else
			{
				$divAttributes['aria-multiselectable'] = 'true';
			}

			/* Scroll-JS funktioniert in dieser simplen Form nicht mit
			multiselectable = JA. Scrollt zum falschen Slider. */
			if ($divAttributes['aria-multiselectable'] === 'false')
			{
				$js = <<<JS
;(function(){
document.addEventListener('DOMContentLoaded',function()
{
document.getElementById("$selector").addEventListener('shown.bs.collapse', function ()
{
	jQuery.fn.scrollToSliderHead("$selector");
});
});})();
JS;
				$this->wa->addInlineScript($js);
				$this->wa->addInline(
					'script',
					$js,
					['name' => 'pagebreaksliderghsvs.HTMLHelper.' . 'selector-' . str_replace(' ', '', $selector)]
				);
			}

			static::$loaded[__METHOD__][$selector] = $opt;

			$divAttributes['class'] = 'panel-group accordion';
			$divAttributes['id'] = $selector;

			return PHP_EOL . '<!--startAccordion-->' . PHP_EOL
				. '<div ' . ArrayHelper::toString($divAttributes) . '>';
		}
	}

	/**
	 * bootstrap.addSlide BS5
	 */
	public static function addSlide(
		$selector,
		$text,
		$id,
		$class = '',
		$headingTagGhsvs = '',
		$title = ''
	) {
		// "in" = BS3. "show" = BS4/BS5.
		//$in = (static::$loaded[__CLASS__ . '::startAccordion'][$selector]['active'] == $id)
		//? ' in show' : '';
		$in = '';
		$parent = '';

		if (!empty(
			static::$loaded[__CLASS__ . '::startAccordion'][$selector]['parent'])
		) {
			// Dies Attribut gehört in den Slide, nicht in den Toggler!
			$parent = ' data-bs-parent="'
				. static::$loaded[__CLASS__ . '::startAccordion'][$selector]['parent']
				. '"';
		}

		$aClass = 'accordion-toggle btn btn-link text-left p-0';

		if (!trim($headingTagGhsvs))
		{
			$headingTagGhsvs = 'div';
		}

		if ($title = trim($title))
		{
			$title = ' <span class="pageBreakSlideTitle">- ' . $title . '</span>';
		}

		$html = [];
		$html[] = '<div class="card pageBreakGhsvsCard">';

		$html[] = '<div class="card-header" id="heading' . $id . '">';
		$html[] = '<' . $headingTagGhsvs . ' class="panel-title">';

		// The Toggler element.
		$html[] = '<button class="' . $aClass . '" data-bs-toggle="collapse"'
			. ' data-bs-target="#collapse' . $id . '" aria-expanded="false"'
			. ' aria-controls="collapse' . $id . '" role="button">';
		$html[] = '{svg{bi/arrows-expand}class="hideIfActive"}';
		$html[] = '{svg{bi/arrows-collapse}class="showIfActive"}';
		$html[] = $text . $title;
		$html[] = '</button>';

		$html[] = '</' . $headingTagGhsvs . '>';
		$html[] = '</div><!--/heading' . $id . '-->';

		$html[] = '<div id="collapse' . $id . '" class="collapse ' . $in . '"'
			. ' aria-labelledby="heading' . $id . '"' . $parent . '>';
		$html[] = '<div class="card-body">';

		return implode("\n", $html);
	}

	public static function endSlide(): string
	{
		return '</div></div></div>';
	}

	public static function endAccordion(): string
	{
		return '</div>';
	}

	public function getWa()
	{
		if (empty($this->wa))
		{
			$this->wa = Factory::getApplication()->getDocument()->getWebAssetManager();
			$this->wa->getRegistry()->addExtensionRegistryFile('plg_system_pagebreaksliderghsvs');
		}

		return $this->wa;
	}
}
