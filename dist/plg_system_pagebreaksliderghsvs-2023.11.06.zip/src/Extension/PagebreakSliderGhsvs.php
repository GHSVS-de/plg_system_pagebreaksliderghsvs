<?php
namespace GHSVS\Plugin\System\PagebreakSliderGhsvs\Extension;

\defined('_JEXEC') or die;

use Exception;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\HTML\HTMLRegistryAwareTrait;
use Joomla\Event\DispatcherInterface;
use GHSVS\Plugin\System\PagebreakSliderGhsvs\Helper\PagebreakSliderGhsvsHelper;
use GHSVS\Plugin\System\PagebreakSliderGhsvs\Service\HTML\PagebreakSliderGhsvsJHtml;

final class PagebreakSliderGhsvs extends CMSPlugin
{
	use HTMLRegistryAwareTrait;

	/**
	 * Load plugin language files automatically
	 *
	 * @var    boolean
	 * @since  3.6.3
	 */
	protected $autoloadLanguage = true;

	private $helper;

	public function __construct(
		DispatcherInterface $dispatcher,
		array $config,
		PagebreakSliderGhsvsHelper $helper,
	) {
		parent::__construct($dispatcher, $config);

		$this->helper = $helper;
	}

	public function onAfterInitialise()
	{
		if (!$this->getApplication()->isClient('administrator'))
		{
			$htmlHelper = new PagebreakSliderGhsvsJHtml();
			$this->getRegistry()->register('pagebreaksliderghsvs', $htmlHelper);
		}
	}

	public function onContentPrepare($context, &$article, &$params, $page = 0)
	{
		if (!$this->getApplication()->isClient('site'))
		{
			return;
		}

		###### pagebreakghsvs-slider - START
		if (
			$context === 'com_content.article'
			&& strpos($article->text, '{pagebreakghsvs-slider ') !== false
		) {
			// empty(id)? E.g. call via 'content.prepare'
			$this->helper->buildSliders($article->text, empty($article->id) ? uniqid() : $article->id);
		}
		###### pagebreakghsvs-slider - END


	}
}
